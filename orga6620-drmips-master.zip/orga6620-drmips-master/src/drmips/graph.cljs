(ns drmips.graph)

(defn- make-line 
  [{x1 :x y1 :y 
    w1 :width h1 :height
    :or {w1 0 h1 0}}
   {x2 :x y2 :y 
    w2 :width h2 :height
    :or {w2 0 h2 0}}]
  (letfn [(start-end-points [x1  x1-max x2  x2-max]
            (cond 
              (<= x1-max x2)           [x1-max x2]
              (<= x1 x2 x2-max x1-max) (let [middle (/ (+ x2 x2-max) 2)]
                                         [middle middle])
              (<= x1 x2 x1-max x2-max) (let [middle (/ (+ x2 x1-max) 2)]
                                         [middle middle])
              (<= x2 x1 x1-max x2-max) (let [middle (/ (+ x1 x1-max) 2)]
                                         [middle middle])
              (<= x2 x1 x2-max x1-max) (let [middle (/ (+ x1 x2-max) 2)]
                                         [middle middle])
              :else              [x1 x2-max]))]

    (let [x1-max (+ x1 w1)
          y1-max (+ y1 h1)
          x2-max (+ x2 w2)
          y2-max (+ y2 h2)
          xs  (start-end-points x1 x1-max x2 x2-max)
          ys  (start-end-points y1 y1-max y2 y2-max) 
          result (reduce #(into %1 %2)
                         (map vector xs ys))]
      result)))



(defn make-path [from   to 
                 start end
                 points]
  (let [from (if start start from)
        to   (if end end to)]
    (if (empty? points) 
      (make-line from to)
      (let [start  (take 2 (make-line from (first points)))
            end    (drop 2 (make-line (last points) to))
            points (map (fn [{:keys [x y]}] [x y]) 
                        points)]
        (into []
              (flatten [start 
                        points
                        end]))))))

