(ns drmips.core
  (:require-macros [cljs.core.async.macros :refer (go)])
  (:require [drmips.graph :refer [make-path]]
            [drmips.events :refer [on-mouse-down]]
            [drmips.components  :refer [properties]]
            [reagent.core :as reagent :refer [atom]]
            [cljs-http.client :as http]
            [cljs.core.async :refer (<!)]
            [garden.core :refer [css]]
            [goog.events :as events]
            [goog.style]))

(goog.style/installStyles
 (css [:circle  
       [:&:hover {:opacity 1.0}]
       {:opacity 0.0}]))

(enable-console-print!)

;; App
(defonce app-state (atom {}))
;; Model update Handlers
(defn change-update [path]
  (fn [event]
    (let [value (-> event .-target .-value)]
      (swap! app-state assoc-in path value))))

(defn update-xy [path x y]
  (swap! app-state
         #(-> %
              (assoc-in (conj path :x) x)
              (assoc-in (conj path :y) y))))

(defn select-cpu-component [path]
  (fn [ _ ]
    (swap! app-state
           #(assoc % :selected-cpu-component path))))

;; JSon download
(go (let [response        (<! (http/get "pipeline.json"))
          keywordize-wire (fn [wire]
                            (reduce #(update %1 %2 keyword)
                             wire
                             [:to :from :out :in]))
          cpu             (-> response
                              (:body)
                              (update :wires #(mapv keywordize-wire  %)))]
      (reset! app-state cpu)))

;; DRAWINGS

(defn draw-box [[component-name {:keys [x y type]  :as data}]]
  (let [path [:components component-name]]
    [:g {:on-click  (select-cpu-component path)
         :on-mouse-down (on-mouse-down
                         (partial update-xy 
                                  path))}
     [:rect (merge {:fill   "white"
                    :fill-opacity 0.0
                    :stroke "black"
                    :x x 
                    :y y} 
                   (properties type))]
     #_[:text {:x x :y (+ y 25)} type]]))

(defn draw-wire-vertex [path {x :x  y :y}]
  [:circle {:cy y
            :cx x
            :r "10"
            :fill "black"
            :on-mouse-down (on-mouse-down (partial update-xy path))}])
 
(defn wire-points 
  [{:keys [to from points end start]}
   components]
  (let [box-to          (get components to)
        box-to          (merge box-to 
                               (properties (:type box-to)))

        box-from        (get components from)
        box-from        (merge box-from 
                               (properties (:type box-from)))]
    (make-path box-from box-to start end points)))

(defn draw-wire [[wire-name wire] components]
  (let [points (wire-points wire 
                                 components)]
    (into 
     [:g [:polyline
          {:points points
           :on-click (select-cpu-component [:wires wire-name])
           :style {:fill   "none"
                   :stroke "black"}}]]
     (->> wire 
          :points 
          (map vector (range))
          (map (fn [[i point]]
                 (draw-wire-vertex [:wires wire-name 
                                    :points i] 
                                   point)))))))

(defn draw-inputs [path component]
  (when-not (nil? component)
    (mapv (fn [[k v]]
            (let [path (conj path k)]
              `[:div {:style {:padding-left "50px"}}
                [:span  ~(name k)]
                ~@(if (map? v)
                    (draw-inputs path v)
                    [[:input {:type "text"
                              :value v
                              :on-change (change-update path)
                              }]])])) 
         component)))

(defn draw-cpu []
  (let [state        @app-state
        components   (->> state
                          :components)
        wires        (->> state
                          :wires
                          (map vector (range))
                          (map #(draw-wire % components)))
        boxes        (->>  components
                           (map draw-box))
        selected-path          (:selected-cpu-component state)
        selected-cpu-component (when selected-path
                                 (get-in state selected-path))]
    [:div
     
     [:div            
      `[:svg {:width 900
              :height 900
              :style {:float "left" }}
        ~@wires
        ~@boxes ]
      `[:div
        {:style {:overflow "hidden"
                 :border "1px solid black"}}
        ~@(draw-inputs selected-path 
                       selected-cpu-component)]]]))

(reagent/render-component
 [draw-cpu]
 (. js/document (getElementById "app")))


#_(defn on-js-reload []
  ;; optionally touch your app-state to force rerendering depending on
  ;; your application
  ;; (swap! app-state update-in [:__figwheel_counter] inc)
  ;; (reset! app-state {})
  ;;(js/console.log (clj->js @app-state))
)

