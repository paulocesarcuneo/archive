(ns drmips.components)


;; Components
(def sizes 
  {"add"  {:width  35
           :height 35}
   "sll"  {:width  40
           :height 40}
   "dmem" {:width  80
           :height 100}
   "sext" {:width  40
           :height 40}
   "and"  {:width  30
           :height 30}
   "or"   {:width  30
           :height 30}
   "not"  {:width  30
           :height 30}
   
   "pipereg" {:width  15
              :height 300}

   "control" {:width  60
              :height 100}
   "regbank" {:width  80
              :height 100}
   "alu" {:width  60
          :height 60}
   "alu_control" {:width  40
                  :height 40}
   "hzd_unit" {:width  70
               :height 50}
   "fork" {:width 3
           :height 3} 
   "dist" {:width  5
           :height 30} 
   "fwd_unit" {:width  70
               :height 50}
   "mux"  {:width  15
           :height 35}
   "PC"   {:width  30
           :height 30}
   "const" {:width  10
            :height 5}

   "imem"  {:width  80
            :height 100}})

(defn properties [data]
  (if-let [dimension (get sizes data)]
    dimension
    {:width 50
     :height 50}))
