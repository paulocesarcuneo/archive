(ns drmips.events
  (:require [goog.events :as events])
  (:import [goog.events EventType]))

(defn rect-offset [e]
  (let [rect        (.getBoundingClientRect (.-target e))
        offset-x    (- (.-clientX e) (.-left rect))
        offset-y    (- (.-clientY e) (.-top  rect))]
    {:x offset-x :y offset-y}))

(defn on-mouse-down [update-xy]
  (fn [this-event]
    (let [{offset-x :x
           offset-y :y} (rect-offset this-event)
          on-move       (fn [event]
                          (let [x (- (.-clientX event) offset-x)
                                y (- (.-clientY event) offset-y)]
                            (update-xy x y)))
          on-mouse-up   (fn [ _ ]
                          (events/unlisten js/window
                                           EventType.MOUSEMOVE
                                           on-move))]
      (events/listen js/window
                     EventType.MOUSEMOVE
                     on-move)
      (events/listen js/window
                     EventType.MOUSEUP
                     on-mouse-up))))

