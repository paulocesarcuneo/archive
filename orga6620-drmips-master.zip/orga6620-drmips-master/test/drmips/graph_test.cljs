(ns drmips.graph-test
  (:require [cljs.test    :refer-macros [deftest is testing run-tests]]
            [drmips.graph :refer [make-line make-path]]))

(deftest make-path-test
  (letfn  [(assert-make-path [{:keys [from to start end points]}
                              expected]
             (is (= expected
                    (make-path from 
                               to 
                               start 
                               end
                               points))))]
    (testing "Only from to rest nil" 
      (assert-make-path {:from {:x 5 :y 5 
                                :width 4 :height 4}
                         :to   {:x 50 :y 50 
                                :width 4 :height 4}}
                        [9 9 50 50]))
    (testing "When :start is set ignore from" 
      (assert-make-path {:from {:x 5 :y 5 
                                :width 4 :height 4}
                         :to   {:x 50 :y 50 
                                :width 4 :height 4} 
                         :start  {:x 30 :y 30}}
                        [30 30 50 50]))
    (testing "When end set ignore to" 
      (assert-make-path {:from {:x 5 :y 5 
                                :width 4 :height 4}
                         :to   {:x 50 :y 50 
                                :width 4 :height 4} 
                         :end  {:x 30 :y 30}}
                        [9 9 30 30]))
    (testing "When both start and end set ignore both" 
      (assert-make-path {:from {:x 5 :y 5 
                                :width 4 :height 4}
                         :to   {:x 50 :y 50 
                                :width 4 :height 4} 
                         :start  {:x 0 :y 0}
                         :end  {:x 30 :y 30}}
                        [0 0 30 30]))
    (testing "When is one point join from at front of points and to at last" 
      (assert-make-path {:from {:x 5 :y 5 
                                :width 4 :height 4}
                         :to   {:x 50 :y 50 
                                :width 4 :height 4} 
                         :points [{:x 10 :y 10}]}
                        [9 9
                         , 10 10
                         , 50 50]))
    (testing "When is two point join from at front of points and to at last" 
      (assert-make-path {:from {:x 5 :y 5 
                                :width 4 :height 4}
                         :to   {:x 50 :y 50 
                                :width 4 :height 4} 
                         :points [{:x 10 :y 10}
                                  {:x 20 :y 10}]}
                        [9 9
                         , 10 10
                         , 20 10
                         , 50 50]))
    (testing "When many point join from at front of points and to at last" 
      (assert-make-path {:from {:x 5 :y 5 
                                :width 4 :height 4}
                         :start {:x 8 :y 8}
                         :to   {:x 50 :y 50 
                                :width 4 :height 4} 
                         :end  {:x 50 :y 54}
                         :points [{:x 10 :y 10}
                                  {:x 20 :y 10}
                                  {:x 20 :y 20}
                                  {:x 30 :y 20}]}
                        [8 8
                         , 10 10
                         , 20 10
                         , 20 20
                         , 30 20
                         , 50 54]))
    (testing "Last points to end from right" 
      (assert-make-path {:from  {:x 710, :y 125, 
                                 :width 3, :height 3} 
                         :to    {:x 470, :y 410, 
                                 :width 70,  :height 50} 
                         :points [{:x 710, :y 450}]}
                        [710 128 710 450 540 450]))))



(deftest make-line-test
  (letfn  [(assert-make-line [[start end] points]
             (is (= points
                    (make-line start end))) )]
    (testing "Just points return the points" 
      (assert-make-line [{:x 10 :y 10}
                         {:x 5 :y 5 }] 
                        [10 10 5 5])
      (assert-make-line [{:x 5 :y 5 }
                         {:x 10 :y 10}] 
                        [5 5 10 10]))
    (testing "Horizontal aligned with point" 
      (assert-make-line [{:x 10 :y 10}
                         {:x 5 :y 5 
                          :width 4 :height 20}] 
                        [10 10 9 10])
      (assert-make-line [{:x 5 :y 5 
                          :width 4 :height 20}
                         {:x 10 :y 10}] 
                        [9 10 10 10]))
    (testing "Vertical aligned with point" 
      (assert-make-line [{:x 10 :y 10}
                         {:x 5 :y 5 
                          :width 20 :height 4}] 
                        [10 10 10 9])
      (assert-make-line [{:x 5 :y 5 
                          :width 20 :height 4}
                         {:x 10 :y 10}] 
                        [10 9 10 10]))
    (testing "Box to box upper left" 
      (assert-make-line [{:x 50 :y 50 
                          :width 4 :height 4}
                         {:x 5  :y 5
                          :width 4 :height 4}] 
                        [50 50 9 9])
      (assert-make-line [{:x 5 :y 5 
                          :width 4 :height 4}
                         {:x 50 :y 50 
                          :width 4 :height 4}] 
                        [9 9 50 50]))
    (testing "Right to left line"
      (assert-make-line [{:x 710, :y 450}
                         {:x 470, :y 410, 
                          :width 70,  :height 50}] 
                        [710 450 540 450]))
    (testing "Take the middle of superposition"
      (assert-make-line [{:x 230 :y 235 
                          :width 3 :height 3}
                         {:x 256 :y 235 
                          :width 80 :height 100}] 
                        [233 236.5 256 236.5]))))

