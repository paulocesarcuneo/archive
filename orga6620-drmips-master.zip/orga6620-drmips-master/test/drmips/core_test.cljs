(ns drmips.core-test
  (:require [cljs.test :refer-macros [deftest is testing run-tests]]
            [drmips.core :as c]))


(enable-console-print!)
(run-tests)
