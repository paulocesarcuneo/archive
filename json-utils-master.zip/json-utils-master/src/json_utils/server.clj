(ns json-utils.server
  (:require [bidi.ring :refer [make-handler]]
            [cheshire.core :refer [decode-stream 
                                   encode]]
            [camel-snake-kebab.core :refer [->kebab-case-keyword 
                                            ->snake_case_string]]
            [ring.util.response :as res]
            [ring.middleware.reload :refer [wrap-reload]]
            [ring.adapter.jetty :refer [run-jetty]]
            [clojure.tools.logging :as log ]))


(defn echo-handler
 "Returns request body as response"
  [request]
  (let [body (:body request)]
    (log/log :info body)
    (-> (res/response body)
        (res/content-type "application/json"))))

(defn echoes-handler
  "Return body and id as response"
  [{:keys [route-params] :as request}]
  (let [id   (:id route-params)
        body (:body request)
        result {:body body :id id}]
    (log/log :info result)
    (-> (res/response result)
        (res/content-type "application/json"))))

(defn wrap-json-request 
  "Transforms body in request to clojure map."
  [handler]
  (fn [request]
    (log/info (pr-str request))
    (letfn [(to-json [body] 
              (with-open [rdr (clojure.java.io/reader body)]
                (decode-stream rdr ->kebab-case-keyword)))]
      (handler (update request :body to-json)))))

(defn wrap-json-response 
  "Transforms body map in response to snake_case_json"
  [handler]
  (fn [request]
    (handler (update request :body encode {:key-fn ->snake_case_string}))))

(def handler 
  "A handler for json api"
  (-> ["/"  {"echo"           echo-handler
             ["echoes/" :id ] echoes-handler}]
      make-handler
      wrap-json-response
      wrap-json-request))


(def reloadable-handler 
  "A reloadable hanlder for repl use"
  (wrap-reload #'handler '(json-utils.server)))

(comment 
  (def Jetty  (run-jetty  reloadable-handler
                              {:port 3000 
                               :join? false}))
  (.start jetty)
  (.stop  jetty))

