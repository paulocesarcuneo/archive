(ns json-utils.json
  (:require [cheshire.core          :refer [decode-stream encode-stream generate-stream]]
            [camel-snake-kebab.core :refer [->snake_case_string
                                            ->kebab-case-keyword]]
            [clojure.java.io :refer [reader writer]]
            [slingshot.slingshot :refer :all] ))


;; FILES
(defn from-json-file [file-name]
  (decode-stream 
   (reader file-name) 
   ->kebab-case-keyword))

(defn to-json-file [file-name data]
  (encode-stream 
   data
   (writer file-name)
   {:key-fn ->snake_case_string
    :pretty true
    :escape-non-ascii true}))

(comment 
  (require '[camel-snake-kebab.extras :refer [transform-keys]])
  (->> (java.util.Date.)
       (bean)
       (transform-keys ->kebab-case)
       :timezone-offset))

