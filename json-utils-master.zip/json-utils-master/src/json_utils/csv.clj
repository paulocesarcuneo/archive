(ns json-utils.csv
  (:require [clojure.data.csv :as csv]
            [clojure.java.io :as io]))

(comment 
  (with-open [in-file (io/reader "in-file.csv")]
    (doall
     (csv/read-csv in-file)))

  (with-open [out-file (io/writer "out-file.csv")]
    (csv/write-csv out-file
                   [["abc" "def"]
                    ["ghi" "jkl"]])))


(defn merge-filter 
  " Given 2 lists a and b,
  returns a list of tuples of 
  elemens from a and b, 
  for with cmp gives 0."
  ([cmp a b]
   (for [a a
         b b
         :when (= 0 (cmp a b))]
     [a b])))

#_(defn merge-algorithm [a b cmp]
 "eficient merge for sorted lists"
     (loop [a b
            a b
            acc []]
       (cond 
         (empty? a) acc
         (empty? b) acc
         (>  0 (cmp (first a) 
                    (first b))) (recur (rest a) b acc) 
         (= 0 (cmp (first a) 
                   (first b))) (recur (rest a) 
                                      (rest b) 
                                      (conj acc [(first a) 
                                                 (first b)]))
         (<  0 (cmp (first a) 
                    (first b))) (recur a (rest b) acc))))
