(ns json-utils.parser
  (:require [instaparse.core :as insta]))

(def syntax
  (insta/parser
   " a-concatenation =  A B ; (* comments: end of rule ';' is optional *)
     an-alternation = A | B ;
     a-grouping = ( A | B );
     an-optional = A? ;       
     a-one-or-more = A+ ;
     a-zero-or-more = A* ;
     a-string = 'some string' ;
     a-regex = #'[0-9]+';
     an-epsilon = Epsilon; (* Epsilon always succeds [< ε eps EPSILON epsilon Epsilon]*)
     filtering = A < '+' > B ; 
     (* every thing inside '<' '>' is parsed but removed from resulting ast.*)
     A = #'[0-9]+' ;
     B = 'someting' ;
      " ))

(def arithmetic
  (insta/parser
   "expr = add-sub
     <add-sub> = mul-div | add | sub
     add = add-sub <'+'> mul-div
     sub = add-sub <'-'> mul-div
     <mul-div> = term | mul | div
     mul = mul-div <'*'> term
     div = mul-div <'/'> term
     <term> = number | <'('> add-sub <')'>
     number = #'[0-9]+'"))

(->> (arithmetic "1-2/(3-4)+5*6")
     (insta/transform
      {:add +, :sub -, :mul *, :div /,
       :number clojure.edn/read-string :expr identity}))
