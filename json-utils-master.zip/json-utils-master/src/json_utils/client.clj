(ns json-utils.client
  (:require [clj-http.client        :as client]
            [cheshire.core          :refer [encode decode]]
            [camel-snake-kebab.core :refer [->snake_case_string 
                                            ->kebab-case-keyword]]
            [slingshot.slingshot :refer :all] ))



(defn post-to 
  "Post map as snake-case json return response body as clojure map"
  [url data]
  (let [body     (encode data {:key-fn ->snake_case_string})
        response (client/post url  {:body    body
                                    :headers {"Accept"       "application/json"
                                              "Content-Type" "application/json"}})]
    (-> response
        :body
        (decode ->kebab-case-keyword))))

(defn get-from
  "Get json response body as clojure map"
  [url]
  (let [response (client/get url {:query-params {}
                                  :headers      {"Accept"       "application/json"
                                                 "Content-Type" "application/json"}})]
    (-> response
        :body
        (decode ->kebab-case-keyword))))



;; EXAMPLES from clj-http
(comment 
  (get-from "https://raw.githubusercontent.com/qneo/json-utils/master/examples/glosarry.json")
  ;; Query parameters
  (client/get "http://site.com/search" {:query-params {"q" "foo, bar"}})

  ;; "Nested" query parameters
  ;; (this yields a query string of `a[e][f]=6&a[b][c]=5`)
  (client/get "http://site.com/search" {:query-params {:a {:b {:c 5} :e {:f 6} }}})

  (client/get "http://example.com"
              {:headers {"foo" ["bar" "baz"], "eggplant" "quux"}
               :accept :json})
  (client/put "http://example.com/api" {:body "my PUT body"})
  (client/post "http://site.com/api"
               {:basic-auth ["user" "pass"]
                :body "{\"json\": \"input\"}"
                :headers {"X-Api-Version" "2"}
                :content-type :json
                :socket-timeout 1000 ;; in milliseconds
                :conn-timeout 1000   ;; in milliseconds
                :accept :json})
  ;; Send form params as a json encoded body (POST or PUT)
  (client/post "http://site.com" {:form-params
                                  {:foo "bar"} :content-type :json})
  
                                        ; Response map is thrown as exception obj.
                                        ; We filter out by status codes
  (try+
   (client/get "http://some-site.com/broken")
   (catch [:status 403] {:keys [request-time headers body]}
     (log/warn "403" request-time headers))
   (catch [:status 404] {:keys [request-time headers body]}
     (log/warn "NOT Found 404" request-time headers body))
   (catch Object _
     (log/error (:throwable &throw-context) "unexpected error")
     (throw+))) 
  ;; (client/get "http://ip.jsontest.com/" {:as :json})
  ;; => {:trace-redirects ["http://ip.jsontest.com/"], :request-time 1153, 
  ;;     :status 200, 
  ;;     :headers {"access-control-allow-origin" "*", 
  ;;               "content-type" "application/json; charset=ISO-8859-1", 
  ;;               "date" "Tue, 22 Oct 2013 19:50:36 GMT", 
  ;;               "server" "Google Frontend",
  ;;               "cache-control" "private", 
  ;;               "alternate-protocol" "80:quic,80:quic", 
  ;;               "connection" "close"}, 
  ;;     :body {:ip "186.54.233.167"}}
  )
