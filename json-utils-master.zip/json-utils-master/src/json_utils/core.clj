(ns json-utils.core
  (:require [cheshire.core :as json]
            [clj-http.client :as client]
            [camel-snake-kebab.core :as format]
            [slingshot.slingshot :refer :all] )
  (:gen-class))




