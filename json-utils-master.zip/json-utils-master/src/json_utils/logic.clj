(ns json-utils.logic
  (:refer-clojure :exclude [==])
  (:require   [clojure.core.logic :refer :all]))

(defn as-vec [m]
  (if (map? m)
    (map (fn [[k v]]
           [(as-vec k) (as-vec v)])
         m)
    m))

(defn embedo [tree subtree]
  (conde 
   [(fresh [x]
      (membero [x subtree] tree))]
   [(fresh [x y]
      (membero [x y] tree)
      (embedo y subtree))]))

(defn patho [tree path child funo]
  (matche 
   [path]
   ([ [?f . ?r ] ]
    (fresh [x]
      (membero [?f x] tree)
      (conde 
       [(emptyo ?r)
        (== ?f child)
        (funo child x)]
       [(patho x ?r child funo)])))))


