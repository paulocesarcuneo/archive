(ns json-utils.logic-test
  (:refer-clojure :exclude [==])
  (:require [clojure.core.logic :refer [== run fresh conde succeed]]
   [json-utils.logic :refer :all]
            [clojure.test :refer :all]))

(deftest patho-test
  (testing "return the paths"
    (let [tree (as-vec {:a {:b {:c :d}}})]
      (is (= '((:a :b :c)) 
             (run 1 [path] 
               (patho tree path :c (fn [x y] succeed))))))))
