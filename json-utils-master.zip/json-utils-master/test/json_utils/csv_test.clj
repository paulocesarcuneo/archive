(ns json-utils.csv-test
  (:require [json-utils.csv :refer :all]
            [clojure.test :refer :all]))

(deftest merge-filter-test
  (testing "2 vectors of numbers"
    (is (= [[2 2] [3 3] [4 4]] 
           (merge-filter compare
                         [2 3 4 5] 
                         [1 2 3 4]))))
  (testing "2 vectors of vectors of numbers"
    (is (= [[[2] [2]] [[3] [3]] [[4] [4]]] 
           (merge-filter compare
                         [[2] [3] [4] [5]] 
                         [[1] [2] [3] [4]])))))
