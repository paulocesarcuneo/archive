(ns json-utils.core-test
  (:require [clojure.test :refer :all]
            [json-utils.core :refer :all]))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
