package qneo.odd;

import static qneo.odd.details.Validate.validateArgs;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

import qneo.odd.api.Config;
import qneo.odd.api.Factory;
import qneo.odd.api.Node;
import qneo.odd.api.Utils;
import qneo.odd.details.Validate;

public class Odd implements Factory {
	private final Executor executor;
	private final Map<Object, Config> nodes = new HashMap<>();
	
	public Odd(Executor executor){
		this.executor = executor;
	}
	
	public Odd() {
		this(Utils.DEFAULT_EXECUTOR);
	}
	
	@Override
	public <A, B> Node<A, B> node(final BiConsumer<A, Consumer<B>> biconsumer) {
		validateArgs(biconsumer != null, "biconsumer cant be null.");
		
		BiConsumer<Exception, Consumer<B>> recovery = Utils.nopRecovery();
		Node<A, B> node = new qneo.odd.details.monothread.Node<A, B>(recovery, biconsumer, this, executor);
		nodes.put(node, new Config(String.valueOf(nodes.size())));
		return node;
	}

	@Override
	public <A, B> Node<A, B> node(final Function<A, B> function) {
		validateArgs(function != null, "function cant be null.");
		BiConsumer<A, Consumer<B>> adapter = Utils.adaptToBiConsumer(function);
		return node(adapter);
	}

	@Override
	public <A, B> Config config(final Node<A, B> node) {
		Validate.validateArgs(nodes.containsKey(node), "The node dont belong to this mesh.");
		return nodes.get(node);
	}

	@Override
	public <A, B> void config(final Node<A, B> node, Config config) {
		Validate.validateArgs(nodes.containsKey(node), "The node dont belong to this mesh.");
		nodes.put(node, config);
	}

}