package qneo.odd;

import static qneo.odd.details.Validate.validateArgs;

import java.io.Closeable;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.SynchronousQueue;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import qneo.odd.api.Config;
import qneo.odd.api.Factory;
import qneo.odd.api.Node;
import qneo.odd.api.Utils;
import qneo.odd.details.Validate;
import qneo.odd.details.multithread.BlockingQueueConection;
import qneo.odd.details.multithread.ConnectedNode;

public class OddMulti implements Factory {
	private static final Logger LOGGER = LoggerFactory.getLogger(OddMulti.class);

	private Executor executor = Executors.newCachedThreadPool();
	private Map<ConnectedNode<?, ?>, Config> nodes = new HashMap<>();

	private static <A> BlockingQueueConection<A> newBlockingQueueConnection() {
		return new BlockingQueueConection<>(new SynchronousQueue<>());
	}

	private Executor nodeExecutor() {
		return Executors.newCachedThreadPool();
	}

	@Override
	public <A, B> Node<A, B> node(BiConsumer<A, Consumer<B>> consumer) {
		validateArgs(consumer != null, "consumer cant be null.");

		BlockingQueueConection<A> connection = newBlockingQueueConnection();
		ConnectedNode<A, B> node = new ConnectedNode<>(nodeExecutor(), connection, consumer, this, Utils.nopRecovery());
		nodes.put(node, new Config("Node-" + String.valueOf(nodes.size())));
		return node;
	}

	@Override
	public <A, B> Node<A, B> node(Function<A, B> function) {
		validateArgs(function != null, "function cant be null.");
		BiConsumer<A, Consumer<B>> adapter = Utils.adaptToBiConsumer(function);
		return node(adapter);
	}

	public void start() throws InterruptedException {
		for (ConnectedNode<?, ?> r : nodes.keySet()) {
			executor.execute(() -> {
				Config config = nodes.get(r);
				if (config.getName() != null) {
					Thread.currentThread().setName(config.getName());
				}
				r.run();
			});
		}
	}

	public CountDownLatch close() throws Exception {
		CountDownLatch latch = new CountDownLatch(nodes.size());
		for (ConnectedNode<?, ?> r : nodes.keySet()) {
			executor.execute(() -> {
				latch.countDown();
				try {
					((Closeable) r).close();
				} catch (Exception e) {
					LOGGER.error("While closing node", e);
				}
			});
		}
		return latch;
	}

	@Override
	public <A, B> void config(Node<A, B> n, Config c) {
		Validate.validateArgs(nodes.containsKey(n), "The node dont belong to this mesh.");
		nodes.put((ConnectedNode<?, ?>) n, c);
	}

	@Override
	public <A, B> Config config(Node<A, B> n) {
		Validate.validateArgs(nodes.containsKey(n), "The node dont belong to this mesh.");
		return nodes.get(n);
	}

}