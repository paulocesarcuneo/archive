package qneo.odd.details;

public interface Validate {

	static void validateLegalState(boolean predicate, String msg) {
		if (!predicate) {
			throw new IllegalStateException(msg);
		}
	}

	static void validateArgs(boolean predicate, String msg) {
		if (!predicate) {
			throw new IllegalArgumentException(msg);
		}
	}
}
