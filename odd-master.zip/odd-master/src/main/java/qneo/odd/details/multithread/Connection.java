package qneo.odd.details.multithread;

import java.io.Closeable;
import java.util.function.Consumer;
import java.util.function.Supplier;

public interface Connection<T> extends Supplier<T>, Consumer<T>, Closeable {

	@Override
	T get();

	@Override
	void accept(T val);

	@Override
	void close();
}