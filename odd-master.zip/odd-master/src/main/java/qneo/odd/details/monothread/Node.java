package qneo.odd.details.monothread;

import static java.util.Optional.ofNullable;
import static qneo.odd.api.Utils.lazyString;
import static qneo.odd.details.Validate.validateLegalState;

import java.util.concurrent.Executor;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import qneo.odd.api.Factory;
import qneo.odd.details.Validate;

public class Node<A, B> implements qneo.odd.api.Node<A, B> {

	private static final Logger LOGGER = LoggerFactory.getLogger(Node.class);
	private Consumer<B> resultConsumer;
	private final BiConsumer<Exception, Consumer<B>> recovery;
	private final BiConsumer<A, Consumer<B>> consumer;
	private final Factory factory;
	private final Executor executor;

	public Node(BiConsumer<Exception, Consumer<B>> recovery, BiConsumer<A, Consumer<B>> consumer, Factory factory,
			Executor executor) {
		super();
		Validate.validateArgs(recovery != null, "recovery can't be null");
		Validate.validateArgs(consumer != null, "consumer can't be null");
		Validate.validateArgs(factory != null, "factory can't be null");
		Validate.validateArgs(executor != null, "executor can't be null");
		this.recovery = recovery;
		this.consumer = consumer;
		this.factory = factory;
		this.executor = executor;
	}

	public void accept(A value) {
		try {
			consumer.accept(value, this::next);
		} catch (Exception e) {
			final Object name = lazyString(() -> ofNullable(factory.config(this).getName()).orElse(""));
			LOGGER.error("{} Consumer error send to recovery.", name, e);
			recovery.accept(e, this::next);
		}
	}

	private void next(B value) {
		if (resultConsumer != null) {
			executor.execute(() -> {
				resultConsumer.accept(value);
			});
		}
	}

	@Override
	public <C> qneo.odd.api.Node<B, C> then(Function<B, C> function) {
		validateLegalState(resultConsumer == null, "Node already sink or connected.");
		Node<B, C> next = (Node<B, C>) factory.node(function);
		resultConsumer = next::accept;
		return next;
	}

	@Override
	public <C> qneo.odd.api.Node<B, C> then(BiConsumer<B, Consumer<C>> biconsumer) {
		validateLegalState(resultConsumer == null, "Node already sink or connected.");
		Node<B, C> next = (Node<B, C>) factory.node(biconsumer);
		resultConsumer = next::accept;
		return next;
	}

	@Override
	public void sink(Consumer<B> consumer) {
		validateLegalState(resultConsumer == null, "Node already sink or connected.");
		this.resultConsumer = consumer;
	}

}