package qneo.odd.details.multithread;

import java.util.Optional;
import java.util.concurrent.BlockingQueue;

/**
 * STATEFULL, don't share instances of this class.
 */
public class BlockingQueueConection<T> implements Connection<T> {
	private final BlockingQueue<Optional<T>> input;

	public BlockingQueueConection(BlockingQueue<Optional<T>> input) {
		super();
		this.input = input;
	}

	@Override
	public void accept(T c) {
		try {
			input.put(Optional.of(c));
		} catch (InterruptedException e) {
			throw new RuntimeException("Failed to send context", e);
		}
	}

	@Override
	public void close() {
		try {
			input.put(Optional.empty());
		} catch (InterruptedException e) {
			throw new RuntimeException("Failed  close.", e);
		}
	}

	public T get() {
		try {
			Optional<T> value = input.take();
			return value.orElse(null);
		} catch (InterruptedException e) {
			throw new RuntimeException("Failed to send context", e);
		}
	}

}
