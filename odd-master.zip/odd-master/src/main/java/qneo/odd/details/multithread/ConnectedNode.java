package qneo.odd.details.multithread;

import static qneo.odd.details.Validate.validateArgs;
import static qneo.odd.details.Validate.validateLegalState;

import java.io.Closeable;
import java.util.Optional;
import java.util.concurrent.Executor;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import qneo.odd.api.Factory;
import qneo.odd.api.Node;

public class ConnectedNode<A, B>
		implements Runnable, qneo.odd.api.Node<A, B>, Closeable, Consumer<A> {

	private static final Logger LOGGER = LoggerFactory.getLogger(ConnectedNode.class);
	private static Consumer<?> NOTHING = ignoredValue -> {	};
	@SuppressWarnings("unchecked")
	private Consumer<B> resultConsumer = (Consumer<B>) NOTHING;
	private Connection<?> parentIn;
	private final BiConsumer<Exception, Consumer<B>> recovery;
	private final Executor executor;
	private final Factory factory;
	private final Connection<A> in;
	private final BiConsumer<A, Consumer<B>> operation;

	public ConnectedNode(Executor executor, Connection<A> in, BiConsumer<A, Consumer<B>> fun, Factory factory,
			BiConsumer<Exception, Consumer<B>> recovery) {
		super();
		this.executor = executor;
		this.in = in;
		this.operation = fun;
		this.factory = factory;
		this.recovery = recovery;
	}

	@Override
	public void run() {
		LOGGER.debug("Node started.");
		while (true) {
			A next = in.get();
			if (next == null) {
				break;
			}
			if (resultConsumer != NOTHING) {
				executor.execute(() -> {
					try {
						operation.accept(next, resultConsumer);
					} catch (Exception e) {
						recovery.accept(e, resultConsumer);
					}
				});
			} else {
				operation.accept(next, resultConsumer);
			}
		}
		LOGGER.debug("Node closing.");
		Optional.ofNullable(resultConsumer)
		.filter(Closeable.class::isInstance)
		.map(Closeable.class::cast)
		.ifPresent(this::closeIt);
		
	}

	private void closeIt(Closeable c) {
		try {
			LOGGER.debug("Close send to consumer.");
			c.close();
		} catch (Exception e) {
			LOGGER.error("While closing consumer.", e);
		}
	}

	@Override
	public void sink(Consumer<B> consumer) {
		validateLegalState(resultConsumer == NOTHING, "Node already sink or connected.");
		this.resultConsumer = consumer;
	}

	@Override
	public <C> Node<B, C> then(BiConsumer<B, Consumer<C>> biconsumer) {
		validateLegalState(resultConsumer == NOTHING, "Node already sink or connected.");
		ConnectedNode<B, C> next = (ConnectedNode<B, C>) factory.node(biconsumer);
		next.parentIn = this.in;
		this.resultConsumer = next;
		return next;
	}

	@Override
	public <C> qneo.odd.api.Node<B, C> then(Function<B, C> f) {
		validateLegalState(resultConsumer == NOTHING, "Node already sink or connected.");
		ConnectedNode<B, C> next = (ConnectedNode<B, C>) factory.node(f);
		next.parentIn = this.in;
		this.resultConsumer = next;
		return next;
	}

	@Override
	public void accept(A t) {
		validateArgs(t != null, "Can't accept null");
		in.accept(t);
	}

	public void close() {
		if (parentIn != null) {
			LOGGER.debug("Send close to parent.");
			parentIn.close();
		} else {
			LOGGER.debug("Closing node connection.");
			in.close();
		}
	}

}