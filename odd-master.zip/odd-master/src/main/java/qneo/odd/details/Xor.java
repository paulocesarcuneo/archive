package qneo.odd.details;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class Xor<T> implements qneo.odd.api.Xor<T>, Closeable {
	private final List<Pair<Predicate<T>, Consumer<T>>> choises = new ArrayList<>();

	public qneo.odd.api.Xor<T> xor(Predicate<T> pred, Consumer<T> value) {
		choises.add(new Pair<>(pred, value));
		return this;
	}

	@Override
	public void close() throws IOException {
		for (Pair<Predicate<T>, Consumer<T>> choise : choises) {
			Consumer<T> second = choise.second();
			if (Closeable.class.isInstance(second)) {
				Closeable.class.cast(second).close();
			}
		}
	}

	@Override
	public void accept(T val) {
		for (Pair<Predicate<T>, Consumer<T>> choise : choises) {
			if (choise.first().test(val)) {
				choise.second().accept(val);
				return;
			}
		}
		Validate.validateArgs(false, "No matching option for XOR input");
	}

}