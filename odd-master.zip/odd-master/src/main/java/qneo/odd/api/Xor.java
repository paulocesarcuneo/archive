package qneo.odd.api;

import java.util.function.Consumer;
import java.util.function.Predicate;

public interface Xor<T> extends Consumer<T> {

	Xor<T> xor(Predicate<T> pred, Consumer<T> value);

	default Xor<T> xor(Consumer<T> value) {
		return this.xor(t -> true, value);
	}

}