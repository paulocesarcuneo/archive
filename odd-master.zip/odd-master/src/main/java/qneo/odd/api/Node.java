package qneo.odd.api;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

public interface Node<A, B> extends Consumer<A>{

	<C> Node<B, C> then(Function<B, C> function);

	<C> Node<B, C> then(BiConsumer<B, Consumer<C>> biconsumer);

	void sink(Consumer<B> consumer);
	
}