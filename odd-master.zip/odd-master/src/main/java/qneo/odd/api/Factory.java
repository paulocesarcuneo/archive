package qneo.odd.api;

import static qneo.odd.details.Validate.validateArgs;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
public interface Factory {
	public static <T> qneo.odd.api.Xor<T> xor(Predicate<T> pred, Consumer<T> consumer) {
		validateArgs(pred != null, "pred cant be null.");
		validateArgs(consumer != null, "consumer cant be null.");
		qneo.odd.details.Xor<T> cond = new qneo.odd.details.Xor<>();
		cond.xor(pred, consumer);
		return cond;
	}
	
	<A, B> qneo.odd.api.Node<A, B> node(BiConsumer<A, Consumer<B>> biconsumer);

	<A, B> qneo.odd.api.Node<A, B> node(Function<A, B> biconsumer);
	
	<A, B> Config config(qneo.odd.api.Node<A, B> node) ;
	
	<A, B> void config(qneo.odd.api.Node<A, B> node, Config config) ;

}