package qneo.odd.api;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public interface Utils {
	Executor INLINE_EXECUTOR  = v -> v.run();
	Executor DEFAULT_EXECUTOR = Executors.newSingleThreadExecutor();

	static <T> BiConsumer<Exception, Consumer<T>> nopRecovery() {
		return (Exception t, Consumer<T> c) -> {
		};
	}

	static <B, A> BiConsumer<A, Consumer<B>> adaptToBiConsumer(final Function<A, B> function) {
		return (A t, Consumer<B> c) -> c.accept(function.apply(t));
	}

	static Object lazyString(Supplier<String> s) {
		return new Object() {
			@Override
			public String toString() {
				try {
					return s.get();
				} catch (Exception e) {
					return "-";					
				}
			}
		};
	} 
}