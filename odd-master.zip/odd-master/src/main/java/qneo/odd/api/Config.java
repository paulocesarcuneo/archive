package qneo.odd.api;

public class Config {
	private String name;
	
	public Config(String name) {
		super();
		this.name = name;
	}

	public Config nameIt(String name) {
		this.name = name;
		return this;
	}

	public String getName() {
		return name;
	}	
}