package qneo.odd.details.monothread;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import org.junit.Assert;
import org.junit.Test;

import qneo.odd.Odd;
import qneo.odd.api.Factory;
import qneo.odd.api.Utils;
import qneo.odd.details.monothread.Node;

public class NodeTest {

	private BiConsumer<Integer, Consumer<Integer>> failingConsumer = (i, c) -> {
		throw new RuntimeException("Test");
	};

	private Factory factory = new Odd();
	private BiConsumer<Exception, Consumer<Integer>> recovery = recoverAs(100);

	private BiConsumer<Exception, Consumer<Integer>> recoverAs(int val) {
		return (e, c) -> c.accept(val);
	}

	@Test
	public void nodeFailure_recovered() throws InterruptedException {
		Node<Integer, Integer> node = new Node<Integer, Integer>(recovery, failingConsumer, factory,
				Utils.DEFAULT_EXECUTOR);

		CountDownLatch done = new CountDownLatch(1);
		AtomicInteger ref = new AtomicInteger(0);
		node.sink((v) -> {
			ref.set(v);
			done.countDown();
		});
		node.accept(1);
		done.await();
		Assert.assertEquals(100, ref.get());
	}

}
