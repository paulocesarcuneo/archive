package qneo.odd.details;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import qneo.odd.api.Utils;
import qneo.odd.details.Xor;
import qneo.odd.details.multithread.ConnectedNode;
import qneo.odd.details.multithread.Connection;

@RunWith(MockitoJUnitRunner.class)
public class XorTest {
	private BiConsumer<Integer, Consumer<Integer>> fun = (i, c) -> c.accept(i);
	@Mock
	private Connection<Integer> in;
	@Mock
	private Xor<Integer> xor;

	@SuppressWarnings("resource")
	@Test
	public void node_closes_xor() throws Exception {
		ConnectedNode<Integer, Integer> node = new ConnectedNode<Integer, Integer>(Utils.DEFAULT_EXECUTOR, in, fun, null,
				null);

		when(in.get()).thenReturn(null);
		node.sink(xor);
		node.run();

		verify(xor).close();
	}

}
