package qneo.odd.integration;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

import org.junit.Before;

import qneo.odd.Odd;

public class MonoTest extends IntegrationTest{
	
	private CountDownLatch countDownLatch;

	protected List<Integer> getValues() {
		System.out.println("values");
		try {
			countDownLatch.await();
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}
		return ref.get();
	}

	protected Consumer<List<Integer>> finalConsumer() {
		return (l) -> {
			ref.set(l);
			countDownLatch.countDown();
		};
	}

	@Before
	public final void init() {
		countDownLatch = new CountDownLatch(1);
		target = new Odd();
		ref = new AtomicReference<List<Integer>>(null);
	}
	
}
