package qneo.odd.integration;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

import org.junit.After;
import org.junit.Before;

import qneo.odd.OddMulti;

public class MultiMeshTest extends IntegrationTest {
	private CountDownLatch countDownLatch;

	protected List<Integer> getValues() {
		System.out.println("values");
		try {
			countDownLatch.await();
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}
		return ref.get();
	}

	protected Consumer<List<Integer>> finalConsumer() {
		return (l) -> {
			ref.set(l);
			countDownLatch.countDown();
		};
	}

	@Before
	public final void init() {
		countDownLatch = new CountDownLatch(1);
		target = new OddMulti();
		ref = new AtomicReference<List<Integer>>(null);

	}

	@Override
	protected void start() {
		System.out.println("start");
		try {
			((OddMulti) target).start();
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}
		System.out.println("started");
	}

	@After
	public final void shutdown() throws Exception {
		System.out.println("closing");
		((OddMulti) this.target).close().await();
		System.out.println("Done");
	}
}
