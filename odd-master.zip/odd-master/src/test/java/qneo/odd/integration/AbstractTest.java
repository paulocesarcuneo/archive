package qneo.odd.integration;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public abstract class AbstractTest {

	public static Function<List<Integer>,List<Integer>> addFun(int i) {
		return listOfInts ->{ listOfInts.add(i); return listOfInts;};
	}
	
	public static BiConsumer<List<Integer>,Consumer<List<Integer>>> addCon(int i) {
		return (listOfInts,consumer ) -> { listOfInts.add(i); consumer.accept(listOfInts);};
	}
	
	public static Predicate<List<Integer>> hasInt(int i) {
		return listOfInts -> listOfInts.contains(i);
	}

}
