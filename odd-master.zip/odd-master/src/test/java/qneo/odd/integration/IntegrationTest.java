package qneo.odd.integration;


import static org.hamcrest.CoreMatchers.hasItems;
import static org.junit.Assert.assertThat;
import static qneo.odd.api.Factory.xor;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

import org.junit.Assert;
import org.junit.Test;

import qneo.odd.api.Factory;
import qneo.odd.api.Node;

public abstract class IntegrationTest extends AbstractTest{
	protected Factory target;
	protected AtomicReference<List<Integer>> ref;
	
	
	protected List<Integer> getValues() {
		return ref.get();
	}

	protected Consumer<List<Integer>> finalConsumer() {
		return ref::set;
	}
	
	protected void start() {
		
	}
	
	@Test
	public void sink_sinkToOtherNodeAddingNumber_listOfNodeValues() {
		Node<List<Integer>, List<Integer>> a = target.node(addFun(0));
		Node<List<Integer>, List<Integer>> b = target.node(addFun(7));
		a.sink(b);
		b.sink(finalConsumer());
		
		start();
		a.accept(new ArrayList<>());
		
		List<Integer> t = getValues();
		assertThat(t, hasItems(0,7));
	}


	
	@Test
	public void then_addNumbersAndSinkRef_expectListOfNumbersAdded() {
		Node<List<Integer>, List<Integer>> a = target.node(addFun(0));
		a
			.then(addFun(1))
			.then(addFun(2))
			.then(addFun(3))
			.then(addFun(4))
			.then(addFun(5))
			.then(addFun(6))
			.sink(finalConsumer());
		
		start();
		a.accept(new ArrayList<>());

		List<Integer> t = getValues();
		assertThat(t, hasItems(0,1,2,3,4,5,6));
	}


	@Test
	public void sink_sinkToConsumer_AddNumberOfConsumer() {
		Node<List<Integer>, List<Integer>> a = target.node(addFun(0));
		Node<List<Integer>, List<Integer>> b = target.node(addCon(1));
		a.sink(b);
		b.sink(finalConsumer());
		start();
		a.accept(new ArrayList<>());

		List<Integer> t = getValues();
		assertThat(t, hasItems(0,1));
	}
	
	@Test
	public void then_addNumbers_allNumberWhereAdded() {
		Node<List<Integer>, List<Integer>> a = target.node(addCon(0));
		a
		.then(addCon(10))
		.then(addCon(20))
		.then(addCon(30))
		.then(addCon(40))
		.then(addCon(50))
		.then(addCon(60))
		.sink(finalConsumer());
	
		start();
		a.accept(new ArrayList<>());
		
		List<Integer> t = getValues();
		assertThat(t, hasItems(0, 10, 20, 30, 40, 50, 60));
	}
	
	@Test
	public void xor_2optionsSink_listWithTheValidOption() {
		Node<List<Integer>, List<Integer>> a = target.node(addFun(0));
		Node<List<Integer>, List<Integer>> b = target.node(addFun(1));
		Node<List<Integer>, List<Integer>> c = target.node(addFun(2));
		
		a.sink(xor(hasInt(2), b).xor(c));
		b.sink(t -> Assert.fail("Unexpected path"));
		c.sink(finalConsumer());
		start();
		a.accept(new ArrayList<>());

		List<Integer> t = getValues();
		assertThat(t, hasItems(0,2));
	}

	@Test
	public void xor_chainedOptionsSink_listWithTheValidOption() {
		Node<List<Integer>, List<Integer>> a = target.node(addFun(0));
		Node<List<Integer>, List<Integer>> b = target.node(addFun(1));
		Node<List<Integer>, List<Integer>> c = target.node(addFun(2));
		
		a.sink(xor(hasInt(0), b).xor(c));
		b.sink(xor(hasInt(2), b).xor(c));
		c.sink(finalConsumer());
		start();
		a.accept(new ArrayList<>());
		
		List<Integer> t = getValues();
		assertThat(t, hasItems(0,1,2));
	}
		
}
