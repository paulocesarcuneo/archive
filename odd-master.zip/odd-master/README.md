# odd

Is a deterministic finite automaton with an async api. 
The idea is to define a graph that connect operations, 
where each operation is run in async.

# implementation

Because continuations are use to connect nodes, stackoverflow can happend if the 
graph is too big or callback are resolved in deep nested callsite. For these reason
every continuation is run on a different thread.




