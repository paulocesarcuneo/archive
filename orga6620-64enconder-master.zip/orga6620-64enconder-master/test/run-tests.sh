#!/usr/bin/env bash

DECODED_STRING="En un lugar de La Mancha de cuyo nombre no quiero acordarme"
ENCODED_STRING="RW4gdW4gbHVnYXIgZGUgTGEgTWFuY2hhIGRlIGN1eW8gbm9tYnJlIG5vIHF1aWVybyBhY29yZGFybWU="

passed=0;
failed=0;

function run () {
  "$@"
  if [[ $? -eq 0 ]];
  then
    ((passed++))
  else
    ((failed++))
  fi;
}

function TestOuputFile () {
  echo "Test Output file"
  echo -n $1 > test/expected;
  echo -n $2 |./tp0 -o test/actual;
  diff test/actual test/expected;
  rm test/expected test/actual
}

function TestInputFile() {
  echo "Test Input file"
  echo -n $2  > test/input;
  echo -n $1  > test/expected;
  ./tp0 -i test/input     > test/actual;
  diff test/actual test/expected;
}

function TestInputOutputFile() {
  echo "Test Input/Ouput file"
  echo -n $2 > test/input;
  echo -n $1 > test/expected;
  ./tp0 -i test/input  -o test/actual;
  diff test/actual test/expected;
  rm test/actual test/expected test/input
}

function TestAgainstBase64Encode () {
  echo "Test Against base 64 Encode"
  diff <(echo -n $1| base64 -w0) <(echo -n $1 | ./tp0);
}

function TestAgainstBase64Decode () {
  echo "Test Against base 64 Decode"
  diff -a  <(echo -n $1 | ./tp0 -d) <(echo -n $1| base64 -d -w0)
}

function TestEncodeDecode {
  echo "Test Encode and Decode "
  diff -a  <(echo -n $1) <(echo -n $1 | ./tp0 | ./tp0 -d)
}

function TestDecode {
  echo "Test Decode "
  diff -a  <(echo -n $2) <(echo -n $1 | ./tp0 -d)
}

run TestOuputFile "$ENCODED_STRING" "$DECODED_STRING"

run TestInputFile "$ENCODED_STRING" "$DECODED_STRING"

run TestInputOutputFile "$ENCODED_STRING" "$DECODED_STRING"

# run TestAgainstBase64Encode "Man is distinguished, not only by his reason, but by this singular passion from other animals, which is a lust of the mind, that by a perseverance of delight in the continued and indefatigable generation of knowledge, exceeds the short vehemence of any carnal pleasure." 

# run TestAgainstBase64Decode "TWFuIGlzIGRpc3Rpbmd1aXNoZWQsIG5vdCBvbmx5IGJ5IGhpcyByZWFzb24sIGJ1dCBieSB0aGlzIHNpbmd1bGFyIHBhc3Npb24gZnJvbSBvdGhlciBhbmltYWxzLCB3aGljaCBpcyBhIGx1c3Qgb2YgdGhlIG1pbmQsIHRoYXQgYnkgYSBwZXJzZXZlcmFuY2Ugb2YgZGVsaWdodCBpbiB0aGUgY29udGludWVkIGFuZCBpbmRlZmF0aWdhYmxlIGdlbmVyYXRpb24gb2Yga25vd2xlZGdlLCBleGNlZWRzIHRoZSBzaG9ydCB2ZWhlbWVuY2Ugb2YgYW55IGNhcm5hbCBwbGVhc3VyZS4="

run TestEncodeDecode "Man is distinguished, not only by his reason, but by this singular passion from other animals, which is a lust of the mind, that by a perseverance of delight in the continued and indefatigable generation of knowledge, exceeds the short vehemence of any carnal pleasure."

run TestDecode "TWFuIGlzIGRpc3Rpbmd1aXNoZWQsIG5vdCBvbmx5IGJ5IGhpcyByZWFzb24sIGJ1dCBieSB0aGlzIHNpbmd1bGFyIHBhc3Npb24gZnJvbSBvdGhlciBhbmltYWxzLCB3aGljaCBpcyBhIGx1c3Qgb2YgdGhlIG1pbmQsIHRoYXQgYnkgYSBwZXJzZXZlcmFuY2Ugb2YgZGVsaWdodCBpbiB0aGUgY29udGludWVkIGFuZCBpbmRlZmF0aWdhYmxlIGdlbmVyYXRpb24gb2Yga25vd2xlZGdlLCBleGNlZWRzIHRoZSBzaG9ydCB2ZWhlbWVuY2Ugb2YgYW55IGNhcm5hbCBwbGVhc3VyZS4=" "Man is distinguished, not only by his reason, but by this singular passion from other animals, which is a lust of the mind, that by a perseverance of delight in the continued and indefatigable generation of knowledge, exceeds the short vehemence of any carnal pleasure."

echo "Total " $((passed + failed))  
echo "Failed  $failed";
