TP0 1er Cuatrimestre de 2016
----------------------------
66.20 Organizacion de Computadoras
----------------------------------
Facultad de Ingenieria, Universidad de Buenos Aires
---------------------------------------------------

Integrantes:
* Paulo Cesar Cuneo, 84840, paulocuneo@gmail.com
* Agustin Alejandro Linari, 81783, agustinlinari@gmail.com
* Pablo Daniel Sívori, 84026, sivoridaniel@gmail.com

Setup ambiente
--------------
Usamos ssh-keys para deployar el emulador, por es necesario crear las keys de deploy almenos una vez.

Iniciar el emulador loguearse y crear el puente ssh al host. El ejemplo muestra el caso donde el emulador esta a la altura de esta carpeta. Por defecto el makefile crear una loopback ip en "172.20.0.1".
```
host$ make gxemul-start GXE_HOME=../gxemul-6620-20070927/
guest# ssh -R 2222:127.0.0.1:22 $(USER)@172.20.0.1
```
Para crear las keys, es necesario hacerlo solo una vez. Va pedir la constraseña del host.
```
host$ make gxemul-setup
```
A partir de ahora se puede deployar al guest/gxemul desde el host.
Por ejemplo para compilar en gxemul, recuperar los archivos assembly y generar el latex.
```
make gxemul-deploy
make gxemul-retrieve-asm
```
Por ultimo esto se corre en el host:
```
make doc
```
Generando asi el informe en doc/report.pdf .

Make commands
-------------
- default:
        Elimina la informacion del binario,  lo compila y ejecuta los test.
- tp-build: 
        Compila el tp generado los archivos *.s y el binario ejecutable.
- tp-clean:
        Elimina el binario del test.
- tp-tests: 
        Corre el script de test de bash sobre binario generado.
- doc: 
        Reconstruye el reporte
- doc-build:
        Construye el reporte.
- doc-clean: 
        Borra los archivos asociados build de reporte.
- gxemul-start:
        Lanzar el enulador es requerido especificar el path al home del emulador: GXE_HOME
- gxemul-deploy:
        Una vez abierto el tunnel ssh copia los archivos *.c la emulador.
- gxemul-setup: 
        Crea un ssh-key y la instala en el emulador, require contraseña.
- gxemul-retrieve-asm:
        Corre el comando make en el emulador por ssh y recupera los documentos *.s generados, 
        copiandolos en la carpeta de donde el tex los requira.
