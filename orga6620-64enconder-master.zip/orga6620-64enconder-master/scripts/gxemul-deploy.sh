cd ..
cd ..
scp -P 2222 -r 64encoder/ root@127.0.0.1:/
