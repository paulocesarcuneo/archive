#include "encoder.h"

int main(int argc, char** argv) 
{
  int status = 0;
  Encoder encoder;
  encoder_init(&encoder);
  encoder_parse(&encoder, argc, argv);
  encoder_process(&encoder);
  if (encoder.success) {
    status = 0;  
  } else {
    status = 1;
  }
  encoder_destroy(&encoder); 
  return status;
}
