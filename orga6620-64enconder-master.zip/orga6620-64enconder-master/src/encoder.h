#ifndef _ENCODER_H_
#define _ENCODER_H_

#include <stdio.h>  /* FILE, fopen, fclose, fgetc, fputc */
#include <unistd.h> 
#include <stdlib.h>
#include <string.h> /* memset */
#include "base64.h"
#include <getopt.h>

typedef struct {
  int success;
  FILE* in;
  FILE* out;
  int encode;
} Encoder;

void encoder_init(Encoder* encoder);

void encoder_parse(Encoder* encoder, int argc, char** argv);

void encoder_process(Encoder* encoder);

void encoder_destroy(Encoder* encoder);

#endif /* _ENCODER_H_ */
