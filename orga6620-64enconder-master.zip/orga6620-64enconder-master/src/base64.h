#ifndef _BASE64_H_
#define _BASE64_H_

#include <stdio.h>  /* FILE, fgetc, fputc */

void to_base64(FILE* in, FILE* out);

void from_base64(FILE* in, FILE* out);

#endif /* _BASE_64_H_ */
