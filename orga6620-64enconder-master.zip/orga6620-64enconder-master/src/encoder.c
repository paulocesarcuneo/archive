#include "encoder.h"
#define  USAGE "Usage:\n\
 tp0 -h\n\
 tp0 -V\n\
 tp0 [options]\n\
Options:\n\
 -V, --version Print version and quit.\n\
 -h, --help    Print this information.\n\
 -o, --output  Path to output file.\n\
 -i, --input   Path to input file.\n\
 -d, --decode  Decode a base64-encoded file.\n\
Examples:\n\
 tp0 -i input.txt -o output.txt\n"

void encoder_process(Encoder* encoder){
  if(encoder->success) {
    if(encoder->encode) {
      to_base64(encoder->in, 
                encoder->out);
    } else {
      from_base64(encoder->in,
                  encoder->out);
    }
  }
}

void encoder_destroy(Encoder* encoder) {
  if(encoder->in != stdin) {
    fclose(encoder->in);
  }
  if(encoder->out != stdout) {
    fclose(encoder->out);
  }
}

void encoder_init(Encoder* encoder) {
  encoder->encode = 1;
  encoder->in  = stdin;
  encoder->out = stdout;
  encoder->success = 1;
}

void encoder_set_in(Encoder* encoder, const char* file_name) {
  FILE* in = NULL;
  if(!encoder->success) {
    return;
  }
  if(encoder-> in != stdin ) {
    encoder->success = 0;
    return;
  }
  in = fopen(file_name,"rb");
  if (in == NULL) {
    encoder->success = 0;
    return;
  } 
  encoder->in = in;
}

void encoder_set_out(Encoder* encoder, const char* file_name) {
  FILE* out = NULL;
  if(!encoder->success) {
    return;
  }
  if(encoder-> out != stdout ) {
    encoder->success = 0;
    return;
  }

  out = fopen(file_name,"wb");
  if (out == NULL) {
    encoder->success = 0;
    return;
  } 
  encoder->out = out;
}

void encoder_parse(Encoder* encoder, int argc, char** argv) {
  #define  GET_OPT_PARAMS  "o:i:deVvh"
  static const struct option long_options[] =
    {{"version", no_argument,       0, 'v'},
     {"help",    no_argument,       0, 'h'},
     {"output",  required_argument, 0, 'o'},
     {"input" ,  required_argument, 0, 'i'},
     {"decode",  no_argument,       0, 'd'},
     {0, 0, 0, 0}};
  int option_index = 0;
  while (1) {
    int opt = getopt_long (argc, argv, GET_OPT_PARAMS, long_options, &option_index);
    if(opt == -1 || !encoder->success) {
      break;
    }
    switch (opt) {
    case 'o':
      encoder_set_out(encoder, optarg);
      break;
    case 'i':
      encoder_set_in(encoder, optarg);
      break;
    case 'd':
      encoder->encode = 0;
      break;
    case 'e':
      encoder->encode = 1;
      break;
    case 'v':
    case 'V':
      fprintf(stderr, _VERSION_);
      encoder->success = 0;
      break;
    default: 
      fprintf(stderr, USAGE);
      encoder->success = 0;
    }
  }
}

