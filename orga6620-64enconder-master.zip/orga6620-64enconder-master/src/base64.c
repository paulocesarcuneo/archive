#include "base64.h"

int to_base64_char (const unsigned char chr) 
{
  static const char BASE64_TABLE[65] = 
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "abcdefghijklmnopqrstuvwxyz"
    "0123456789+/";
  return BASE64_TABLE[ 0x3F & chr ];
} 

int from_base64_char (const unsigned char chr) 
{
/*         1         2         3         4         5         6
 0123456789012345678901234567890123456789012345678901234567890123
"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"   */
  if( 'A' <= chr && chr <= 'Z') {
    return chr - 'A';
  }
  if( 'a' <= chr && chr <= 'z') {
    return chr - 'a' + 26;
  }
  if( '0' <= chr && chr <= '9') {
    return chr - '0' + 52;
  }
  if(chr =='+') {
    return 62;
  }
  if(chr =='/') {
    return 63;
  }
  return '=';
} 

void to_base64(FILE* in, FILE* out) 
{
  unsigned int reminder = 0;
  unsigned int current64 = 0;
  int i = 0;
  int current_byte = fgetc(in);
  while(!feof(in)) {
    switch (i % 3) {
    case 0: 
      current64 = current_byte >> 2;
      fputc(to_base64_char(current64), out);
      reminder  = (current_byte & 0x03) << 4;
      break;
    case 1: 
      current64 = ((current_byte & 0xF0 ) >> 4) | reminder;
      fputc(to_base64_char(current64), out);
      reminder  = (current_byte & 0x0F) << 2;
      break;
    case 2: 
      current64 = ((current_byte & 0xC0 ) >> 6) | reminder;
      fputc(to_base64_char(current64), out);
      current64 = current_byte & 0x3F;
      fputc(to_base64_char(current64), out);
      break;
    }
    i += 1;
    current_byte = fgetc(in);
  } 
  
  switch(i % 3) {
  case 0: 
    break;
  case 1: 
    current64 = reminder;
    fputc(to_base64_char(current64), out);
    fputc('=', out);
    fputc('=', out);
    break;
  case 2: 
    current64 = reminder;
    fputc(to_base64_char(current64), out);
    fputc('=', out);     
    break;
  }
}

void from_base64(FILE* in, FILE* out) 
{
  unsigned int current_byte = 0;
  unsigned int reminder = 0;
  int i = 0;
  unsigned int current64 = fgetc(in);
  while(!feof(in) && ('=' != current64)) {
    current64 = from_base64_char(current64); 
    switch (i % 4) {
    case 0: 
      reminder = current64 << 2;
      break;
    case 1: 
      current_byte = current64 >> 4 | reminder;
      fputc(current_byte, out);
      reminder  = 0x0F & current64;
      break;
    case 2: 
      current_byte = current64 >> 2 | reminder << 4;
      fputc(current_byte, out);
      reminder  = 0x03 & current64;
      break;
    case 3:
      current_byte = current64 | reminder << 6;
      fputc(current_byte, out);
      break;      
    }
    i += 1;
    current64 = fgetc(in);
  }

}
