(ns courses.core-test
  (:require [courses.core :refer :all]
            [clojure.test 
             :refer  [deftest is testing]
             :refer-macros [thrown?]]))


(deftest course-enroll-test
  (do (reset! course-view   {0 {:name "Course0" :vacancy 1}
                             1 {:name "Course1" :vacancy 1}})
      (reset! student-view  {0 {:first-name "FirstName1" :last-name "LastName2"}})
      (reset! enrolled-view nil)
      (reset! enrollments-store {})
      (testing "Enroll a non existing student. Throws exception."
        (is (thrown? Exception 
                     (process-event {:event :enroll 
                                     :student-id -1 
                                     :course-id   0}))))
      (testing "Enroll a non existing course. Throws exception."
        (is (thrown? Exception 
                     (process-event {:event :enroll 
                                     :student-id 0 
                                     :course-id -1}))))
      (testing "Enroll a student in a course. Adds event to enrollments"
        (do (process-event {:event :enroll 
                            :student-id 0 
                            :course-id  0})
            (is (= @enrollments-store {0 [{:event :enroll 
                                           :student-id 0 
                                           :course-id  0}]}))))
      (testing "Vacancy limit reached. Throws exception."
        (do (process-event {:event :enroll 
                            :student-id 0 
                            :course-id  1})
            (is (thrown? Exception 
                         (process-event {:event :enroll 
                                         :student-id 0 
                                         :course-id  1})))))
      (testing "Unenroll ."
        (do (reset! enrollments-store {})
            (process-event {:event :enroll 
                            :student-id 0 
                            :course-id  0})
            (process-event {:event :unenroll
                            :student-id 0 
                            :course-id  0})
            (is (= @enrollments-store {0 [{:event :enroll 
                                           :student-id 0 
                                           :course-id  0}
                                          {:event :unenroll 
                                           :student-id 0 
                                           :course-id  0}]}))))))
