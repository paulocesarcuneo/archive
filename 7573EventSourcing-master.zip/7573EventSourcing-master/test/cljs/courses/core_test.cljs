(ns courses.core-test
  (:require-macros [cljs.test :refer (is deftest testing)])
  (:require [cljs.test]))

(deftest example-passing-test
  (is (= 1 1)))
