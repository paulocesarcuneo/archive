(ns courses.test-runner
  (:require
   [doo.runner :refer-macros [doo-tests]]
   [courses.core-test]
   [courses.common-test]))

(enable-console-print!)

(doo-tests 'courses.core-test
           'courses.common-test)
