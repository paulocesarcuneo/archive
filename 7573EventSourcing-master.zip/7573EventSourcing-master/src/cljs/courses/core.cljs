(ns courses.core
  (:require [reagent.core :as reagent :refer [atom]] 
            [ajax.core :refer [POST GET DELETE]]
            [cljs.reader :as edn]))

(enable-console-print!)

(defonce app-state (atom {:refresh-job nil
                          :courses []
                          :students []}))



;; Controller & helpers
(defn refresh-admin [ _ ]                       
  (GET "/api/students/" 
       {:headers {:content-type "application/edn"}
        :handler #(swap! app-state assoc :students (edn/read-string %))
        :error-handler #(println "Err" %)})
  (GET "/api/courses/" 
       {:headers {:content-type "application/edn"}
        :handler #(swap! app-state assoc :courses (edn/read-string %))
        :error-handler #(println "Err" %)}))

;; Controller
(defn controller [action & args]
  (case action
    :unenroll (let [[student-id course-id] args]
                (fn [_]
                  (POST (str "/api/students/" 
                             student-id 
                             "/enrollments")
                        {:body (pr-str {:course-id  course-id 
                                        :student-id student-id
                                        :event :unenroll})
                         :headers {:content-type "application/edn"}
                         :handler (fn [res]
                                    (let [res (edn/read-string res)]
                                      (swap! app-state 
                                             assoc
                                             :logged
                                             res)))})))
    :enroll   (let [[student-id course-id] args]
                (fn [_]
                  (POST (str "/api/students/" 
                             student-id 
                             "/enrollments")
                        {:body (pr-str {:course-id  course-id 
                                        :student-id student-id
                                        :event :enroll})
                         :headers {:content-type "application/edn"}
                         :handler (fn [res]
                                    (let [res (edn/read-string res)]
                                      (swap! app-state 
                                             assoc
                                             :logged
                                             res)))})))
    :set           (fn [e]
                     (swap! app-state 
                            assoc-in
                            args 
                            (-> e .-target .-value)))
    :login         (fn [_]  
                     (let [student-id (get-in @app-state [:user :id])]
                       (GET (str  "/api/students/" student-id)
                            {:headers {:content-type "application/edn"}
                             :handler (fn [res]
                                        (swap! app-state
                                               (fn [state]
                                                 (-> state
                                                     (assoc :logged
                                                            (edn/read-string res))
                                                     (dissoc :user)))))
                             :error-handler #(println "Err" %)})))
    :logout       (fn [ _ ]
                    (swap! app-state 
                           dissoc
                           :logged))

    :del-course   (let [[course-id] args]
                    (fn [_]
                      (DELETE (str "/api/courses/" course-id) 
                              {:headers {:content-type "application/edn"}
                               :handler (fn [_ ]
                                          (swap! app-state
                                                 update 
                                                 :courses
                                                 (fn [courses]
                                                   (remove #(-> % 
                                                                :id
                                                                (= course-id))
                                                           courses))))})))
    
    :del-student  (let [[student-id] args]
                    (fn [_]
                      (DELETE (str "/api/students/" student-id) 
                              {:headers {:content-type "application/edn"}
                               :handler (fn [_ ]
                                          (swap! app-state
                                                 update 
                                                 :students
                                                 (fn [students]
                                                   (remove #(-> % 
                                                                :id
                                                                (= student-id))
                                                           students))))})))
    :add-course   (fn [_]
                    (let [course (->  @app-state
                                      :course
                                      (update :quota
                                              edn/read-string))]
                      (POST "/api/courses"
                            {:body (pr-str course)
                             :headers {:content-type "application/edn"}
                             :handler (fn [course]
                                        (let [course (edn/read-string course)]
                                          (-> app-state
                                              (swap! #(-> %
                                                          (update
                                                           :courses
                                                           conj 
                                                           course)
                                                          (dissoc :course))))))})))
    :add-student  (fn [_]
                    (let [student (get @app-state
                                       :student)]
                      (POST "/api/students"
                            {:body (pr-str student)
                             :headers {:content-type "application/edn"}
                             :handler (fn [student]
                                        (let [student (edn/read-string student)]
                                          (-> app-state
                                              (swap! #(-> %
                                                          (update
                                                           :students
                                                           conj 
                                                           student)
                                                          (dissoc :student))))))})))))
;; View
(defn login []
  [:div 
   [:div 
    [:span "UserId: " 
     [:input  {:type :text
               :on-change (controller :set 
                                      :user 
                                      :id)}]
     [:button {:on-click  (controller :login)} "Login"]]]])

(defn courses []
  (let [{courses               :courses
         {:keys [name quota]} :course} @app-state]
    [:div 
     `[:div "Id Course Quota (Vacancy)"
       ~@(for [{name     :name
                id       :id
                vacancy  :vacancy
                quota    :quota}  courses]
           [:div [:span  (str id) " " name " " quota  " (" vacancy ")"] 
            [:button {:on-click (controller :del-course id)} "Del"]])]
     [:div 
      [:div
       [:span "Name: " 
        [:input {:value name
                 :on-change (controller :set :course :name)}]]]
      [:div
       [:span "Quota: " 
        [:input {:value quota
                 :on-change (controller :set :course :quota)}]]]
      [:button {:on-click (controller :add-course)} "Add"]]]))


(defn student []
  (let [{{:keys [first-name last-name]} :student 
         students :students} @app-state]
    [:div 
     `[:div {:style {:display :table}} "Id - First Name - Last Name"
       ~@(for [{:keys [first-name last-name id]}  students]
           `[:div {:style {:display :table-row}}
             ~@(mapv (fn [v] 
                       [:div {:style {:display :table-cell}} 
                        [:span v ]])
                     [(str id)  first-name  last-name]) 
             [:div {:style {:display :table-cell}}
              [:button {:on-click ~(controller :del-student id)} "Del"]]])]
     [:div 
      [:div 
       [:span "First Name: "
        [:input {:value first-name
                 :on-change (controller :set :student :first-name)}]]]
      [:div
       [:span "Last Name: "
        [:input {:value last-name
                 :on-change (controller :set :student :last-name)}]]]
      [:button {:on-click (controller :add-student)} "Add"]]]))

(defn enrollment []
  (let [{{student-name :first-name
          student-id   :id
          enrolled     :enrollments
          courses      :courses
          :or { enrolled #{}} } :logged} @app-state]
    [:div
     [:div 
      [:span "Hola " student-name " !" 
       [:button {:on-click (controller :logout)} "Logout"]]]
     `[:div 
       [:div "Course" "(Vacancy)"]
       ~@(for [{name     :name
                id       :id
                vacancy  :vacancy}  courses]
           [:div [:span name " (" vacancy ")"] 
            [:button {:on-click 
                      (controller  (if (enrolled id)
                                     :unenroll
                                     :enroll)
                                   student-id 
                                   id)} 
             (if (enrolled id) 
               "Unenroll" 
               "Enroll")]])]]))

(defn app []
  [:div {:style {:display :table
                 :width "100%"}} 
   [:div {:style {:display :table-row}} 
    [:div {:style {:display :table-cell 
                   :width "50%"}} 
     [:h1 "User View"]
     (let [logged (get @app-state :logged)]
       (if logged
         [enrollment]
         [login]))]
    [:div {:style {:display :table-cell
                   :width "50%"}}
     [:h1 "Admin View" [:button {:on-click 
                                 (fn [] (swap! app-state 
                                              update 
                                              :refresh-job
                                              (fn [job]
                                                (if job
                                                  (do  (js/clearInterval job)
                                                       nil)
                                                  (js/setInterval (fn []
                                                                    (refresh-admin nil))
                                                                  3000)))))} 
                        (if (:refresh-job @app-state)
                          "Stop"
                          "Refresh")]]
     [courses]
     [student]]]])

(reagent/render 
 [app]
 (js/document.getElementById "app"))

(refresh-admin nil)

