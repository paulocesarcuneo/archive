(ns courses.students
  (:require [onelog.core :as log])
  (:gen-class))

(def student-view (atom {}))
(def student-store (atom {}))

(defn create-student [student]
  (let [id (java.util.UUID/randomUUID)
        student (assoc student :id id)]
    (swap! student-view 
           assoc
           id 
           student)
    (swap! student-store
           assoc  
           id 
           [{:event   :create 
             :student student}]) 
    student))

(defn update-student [{id :id :as student}]
  (swap! student-store
         update 
         id
         (fn [events]
           (when (empty? events)
             (throw (ex-info "Student does not exists"
                             {:id id})))
           (when-not (->>  events 
                           (map :event)
                           (filter :delete)
                           empty?)
             (throw (ex-info "Student Deleted"
                             {:id id})))
           
           (conj events  
                 {:event   :update
                  :student student})))
  (-> (swap! student-view 
             update
             id 
             merge
             student)
      vals
      first))

(defn delete-student [id]
  (swap! student-store
         update 
         id
         (fn [events]
           (when (empty? events)
             (throw (ex-info "Student Does not exists"
                             {:id id})))
           (when-not (->>  events 
                           (map :event)
                           (filter :delete)
                           empty?)
             (throw (ex-info "Student Deleted"
                             {:id id})))
           (conj events  
                 {:event :delete :id id})))
  (swap! student-view 
         dissoc
         id)
  {})
