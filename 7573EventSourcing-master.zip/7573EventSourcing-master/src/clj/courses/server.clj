(ns courses.server
  (:require [clojure.java.io :as io]
            [compojure.core :refer [ANY GET PUT POST DELETE defroutes context]]
            [compojure.route :refer [resources]]
            [ring.middleware.defaults :refer [wrap-defaults api-defaults]]
            [ring.middleware.gzip :refer [wrap-gzip]]
            [ring.middleware.logger :refer [wrap-with-logger]]
            [ring.util.response :refer [response content-type]]
            [environ.core :refer [env]]
            [ring.adapter.jetty :refer [run-jetty]]
            [courses.core :as c]
            [courses.courses :as cc]
            [courses.students :as cs]
            [onelog.core :as log]
            [clojure.data.json :as json])
  (:import [java.io PushbackReader])
  (:gen-class))

(defn t-map 
  ([& fns]
   (fn [coll]
     (map #(%1 %2) 
          (concat fns (repeat identity))
          coll))))


(defroutes routes
  (GET "/"
       _
       {:status 200
        :headers {"Content-Type" "text/html; charset=utf-8"}
        :body (io/input-stream (io/resource "public/index.html"))})
  (resources "/")
  (GET "/api/stores/:store" 
       {{store :store} :params} 
       (-> (case store
             "students"    @cs/student-store
             "courses"     @cc/course-store
             "enrollments" @c/enrollments-store
             nil)
           (json/write-str :value-fn (fn [k v]
                                       (if (uuid? v)
                                         (str v)
                                         v)))
           response
           (content-type "application/json")))
  (context "/api/students" 
           _
           (GET "/"
                _
                (response (vals @cs/student-view)))
           (POST "/"
                 {body :body}
                 (-> body
                     cs/create-student
                     response))
           (DELETE "/:id"
                   {{id :id} :params}
                   (do (log/info id)
                       (-> id 
                           java.util.UUID/fromString
                           cs/delete-student
                           response)))
           (GET "/:id"
                {{id :id} :params}
                (response (let [student (->> id 
                                             java.util.UUID/fromString
                                             (get @cs/student-view))
                                courses (->> @cc/course-view 
                                             vals)]
                            (assoc student :courses courses))))
           (GET "/:id/enrollments" 
                {{student-id :id} :params} 
                (->> @c/enrollments-store 
                     (filter #(= (:student-id %) student-id))
                     (group-by :course-id)
                     (map (t-map identity c/net-enrolled))
                     (filter #(> (second %) 1))
                     (map first)
                     (response)))

           (POST "/:id/enrollments" 
                 {{student-id :id} :params
                  body                     :body} 
                 (response  (let [_       (-> body
                                              (assoc :student-id
                                                     (java.util.UUID/fromString student-id))
                                              c/process-event)
                                  student (->> student-id
                                               java.util.UUID/fromString
                                               (get @cs/student-view))
                                  courses (->> @cc/course-view 
                                               vals)]
                              (assoc student :courses courses)))))

  (context "/api/courses" 
           _
           (GET "/"
                _
                (response (vals @cc/course-view)))
           (POST "/"
                 {body :body}
                 (-> body
                     cc/create-course
                     response))
           (DELETE "/:id"
                   {{id :id} :params}
                   (do (log/info id)
                       (-> id 
                           java.util.UUID/fromString
                           cc/delete-course
                           response)))))


(defn wrap-content-type-edn [handler]
  (fn [request]
    (let [ct (get-in request [:headers "content-type"])]
      (if (= "application/edn" ct)
        (do 
          (-> request
              (update :body 
                      (fn [req]
                        (if req
                          (clojure.edn/read-string (slurp req))
                          req)))
              handler
              (update :body 
                      #(pr-str %))
              (content-type ct)))
        (handler request)))))

(def http-handler
  (-> routes
      wrap-content-type-edn
      (wrap-defaults (dissoc  api-defaults :not-modified-responses))
      wrap-with-logger
      wrap-gzip))

(defn -main [& [port]]
  (let [port (Integer. (or port (env :port) 10555))]
    (run-jetty http-handler {:port port :join? false})))

