(ns courses.courses
  (:gen-class))

(def course-view (atom {}))
(def course-store (atom {}))


(defn create-course [course]
  (let [id (java.util.UUID/randomUUID)
        course (-> course
                   (assoc :id id)
                   (assoc :vacancy (:quota course)))]
    (swap! course-view 
           assoc
           id 
           course)
    (swap! course-store
           assoc  
           id 
           [{:event   :create 
             :course course}]) 
    course))

(defn update-course [{id :id :as course}]
  (swap! course-store
         update 
         id
         (fn [events]
           (when (empty? events)
             (throw (ex-info "Course does not exists"
                             {:id id})))
           (when-not (->>  events 
                           (map :event)
                           (filter :delete)
                           empty?)
             (throw (ex-info "Course Deleted"
                             {:id id})))
           
           (conj events  
                 {:event   :update
                  :course course})))
  (-> (swap! course-view 
             update
             id 
             merge
             course)
      vals
      first))

(defn delete-course [id]
  (swap! course-store
         update 
         id
         (fn [events]
           (when (empty? events)
             (throw (ex-info "Course Does not exists"
                             {:id id})))
           (when-not (->>  events 
                           (map :event)
                           (filter :delete)
                           empty?)
             (throw (ex-info "Course Deleted"
                             {:id id})))
           (conj events  
                 {:event :delete :id id})))
  (swap! course-view 
         dissoc
         id)
  {})



