(ns courses.core
  (:require [courses.students :as cs]
            [courses.courses  :as cc])
  (:gen-class))

;; VIEW AND VIEW UPDATE METHODS
;; atom es un atomic reference en clojure.

(def course-view  cc/course-view)

(def student-view cs/student-view)

(def enrolled-view (atom {}))

;; defmulti declara un funcion con multiple dispatch,
;; en este caso el dispatch es sobre :event
(defmulti update-view :event)

;;defmethod declara una caso del multiple dispatch
(defmethod update-view 
  :unenroll 
  [{:keys [student-id course-id]}]
  ;; swap! cambia el valor de atom, 
  ;; invokando la funcion y los argumentos recibidos.
  (swap! student-view
         update-in
         [student-id :enrollments]
         (fn [enrolls]
           (disj enrolls course-id)))
  (swap! course-view 
         update-in
         [course-id :vacancy]
         (fnil inc 0))
  (swap! enrolled-view 
         update
         course-id
         (fnil inc 0)))

(defmethod update-view 
  :enroll 
  [{:keys [course-id student-id]}]
  (swap! student-view
         update-in
         [student-id :enrollments]
         (fnil conj #{})
         course-id)
  (swap! course-view
         update-in
         [course-id :vacancy] 
         (fnil dec 0))
  (swap! enrolled-view
         update
         course-id
         (fnil dec 0)))

;; EVENT STORE
(def enrollments-store  (atom {}))

(defn must-be-not-nil 
  [err-msg err-info  data]
  (when (nil? data)
    (throw (ex-info err-msg 
                    err-info)))
  data)

(defn get-course 
  [{:keys [course-id]}]
  (get @course-view 
       course-id))

(defn get-student 
  [{:keys [student-id]}]
  (get @student-view 
       student-id))

(defn net-enrolled 
  [events] 
  (->> events
       (map :event)
       (map #(case %
               :enroll   1
               :unenroll -1
               0)) 
       (reduce +)))

(defn remaining-vacancy 
  [{:keys [quota]} enrollments]
  (- quota 
     (net-enrolled 
      enrollments)))

(defmulti process-event :event)

(defn must-be [pred msg info val]
  (if-not (pred val)
    (throw (ex-info msg info))
    val))

(defn filter-student-id [id events]
  (filter #(-> %
               :student-id
               (= id))
          events))

(defn count-student-enrollments [student-id enrollments]
  (->> enrollments
       (filter-student-id student-id)
       (net-enrolled)))

(defn must-be-enroll [event enrollments]
  (must-be #(= % 1)
           "Student not enrolled"
           event
           (count-student-enrollments 
            (:student-id event)
            enrollments)))

(defmethod process-event 
  :unenroll 
  [event]
  (let [course  (must-be-not-nil "Course not found" 
                                 event
                                 (get-course event))
        student (must-be-not-nil "Student not found"
                                 event
                                 (get-student event))]
    (swap! enrollments-store
           update
           (:course-id event)
           (fn [enrollments]
             (must-be-enroll event 
                             enrollments)
             (update-view event)
             ((fnil conj []) 
              enrollments 
              event)))))

(defn must-be-not-enroll [event enrollments]
  (must-be #(<= % 0)
           "Student already enrolled"
           event
           (count-student-enrollments 
            (:student-id event)
            enrollments)))

(defn must-be-vacant [event course enrollments]
  (must-be #(> % 0)
           "No more vacancy"
           event
           (remaining-vacancy course 
                              enrollments)))

(defmethod process-event
  :enroll 
  [event]
  (let [course  (must-be-not-nil "Course not found" 
                                 event
                                 (get-course event))
        student (must-be-not-nil "Student not found"
                                 event
                                 (get-student event))]
    (swap! enrollments-store
           update
           (:course-id event)
           (fn [enrollments]
             (must-be-not-enroll event 
                                 enrollments)
             (must-be-vacant event 
                             course 
                             enrollments)
             (update-view event)
             ((fnil conj []) 
              enrollments 
              event)))))

